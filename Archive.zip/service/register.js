const AWS = require('aws-sdk');
11``
AWS.config.update({
  region:'ap-south-1'
})
const util = require('../utils/util')
const bcrypt = require('bcryptjs')

const dynamodb = new AWS.DynamoDB.DocumentClient();
const userTable = 'artist';

async function register(userInfo) {
  const email=userInfo.email;
  const name=userInfo.artistName;
  const password=userInfo.password;
  const artistType=userInfo.artistType;
  const bio=userInfo.bio;
  if(!email || !name || !password || !artistType || !bio){
    return util.buildResponse(401, {
      message:'All fields are required'
    });
  }

  const dynamoUser = await getUser(email);
  if(dynamoUser && dynamoUser.email){
    return util.buildResponse(401, {
      message: "User is already exist in our system.Kindly please login"
    });
  }

  const encryptedPW = bcrypt.hashSync(password.trim(), 10);
  const user = {
    email : email,
    name : name,
    password : encryptedPW,
    artistType : artistType.toLowerCase().trim(),
    bio : bio.toLowerCase().trim()
  }

  const saveUserResponse = await saveUser(user);
  if(!saveUserResponse) {
    return util.buildResponse(503, { 
      message: 'Server Error. Please try again later,'
    });
  }

  return util.buildResponse(200, {
    email:email
  })

}

async function getUser(email) {
  const params = {
    TableName:userTable,
    key : {
      email:email
    }
  }
  return await dynamodb.get(params).promise().then(response => {
    return response.Item;
  }, error => {
    console.error('There is an error getting user: ',error);
  });
}

async function saveUser(user) {
  const params = {
    TableName: userTable,
    Item: user
  }
  return await dynamodb.put(params).promise().then(() => {
    return true;
  }, console.error('There is an error in saving user: ',error ));
}

module.exports.register=register;
